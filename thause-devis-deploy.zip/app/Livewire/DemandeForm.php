<?php

namespace App\Livewire;

use App\Models\Categorie;
use App\Models\Commune;
use App\Models\Demande;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.app')]
class DemandeForm extends Component
{
    public int $nb_passagers = 30;
    public ?int $categorie_id = null;

    public string $client_nom = '';
    public string $client_email = '';
    public string $client_telephone = '';
    public string $commentaire = '';

    /** @var array<int, array<string, mixed>> */
    public array $etapes = [];

    /** Champ piège anti-robot (doit rester vide). */
    public string $website = '';

    public bool $submitted = false;
    public ?string $reference = null;

    public function mount(): void
    {
        // On démarre avec 2 étapes : le départ et l'arrivée.
        $this->etapes = [$this->etapeVide(), $this->etapeVide()];
    }

    protected function etapeVide(): array
    {
        return [
            'commune_id'         => null,
            'date'               => '',
            'heure_arrivee'      => '',
            'heure_depart'       => '',
            'arrivee_imperative' => false,
            'depart_imperatif'   => false,
        ];
    }

    public function ajouterEtape(): void
    {
        $this->etapes[] = $this->etapeVide();
    }

    public function retirerEtape(int $index): void
    {
        if (count($this->etapes) <= 2) {
            return; // on garde au minimum un départ et une arrivée
        }
        unset($this->etapes[$index]);
        $this->etapes = array_values($this->etapes);
    }

    /** Si le nombre de passagers change, on invalide une catégorie devenue trop petite. */
    public function updatedNbPassagers(): void
    {
        if ($this->categorie_id) {
            $cat = Categorie::find($this->categorie_id);
            if (! $cat || $cat->capacite < $this->nb_passagers) {
                $this->categorie_id = null;
            }
        }
    }

    /** Catégories dont la capacité couvre le nombre de passagers demandé. */
    public function getCategoriesProperty()
    {
        return Categorie::query()
            ->where('actif', true)
            ->where('capacite', '>=', max(1, $this->nb_passagers))
            ->orderBy('capacite')
            ->get();
    }

    /** Communes disponibles (jeu de démo ; import BAN complet en Phase 1). */
    public function getCommunesProperty()
    {
        return Commune::query()->orderBy('nom')->get();
    }

    protected function rules(): array
    {
        return [
            'nb_passagers'              => ['required', 'integer', 'min:1', 'max:120'],
            'categorie_id'             => ['required', 'exists:categories,id'],
            'client_nom'               => ['required', 'string', 'max:255'],
            'client_email'             => ['required', 'email', 'max:255'],
            'client_telephone'         => ['nullable', 'string', 'max:30'],
            'commentaire'              => ['nullable', 'string', 'max:2000'],
            'etapes'                   => ['required', 'array', 'min:2'],
            'etapes.*.commune_id'      => ['required', 'exists:communes,id'],
            'etapes.*.date'            => ['required', 'date'],
            'etapes.*.heure_arrivee'   => ['nullable', 'date_format:H:i'],
            'etapes.*.heure_depart'    => ['nullable', 'date_format:H:i'],
        ];
    }

    protected function messages(): array
    {
        return [
            'categorie_id.required'       => 'Merci de choisir une catégorie de véhicule.',
            'etapes.*.commune_id.required' => 'Indiquez la ville de chaque étape.',
            'etapes.*.date.required'      => 'Indiquez la date de chaque étape.',
            'client_email.email'          => 'Adresse e-mail invalide.',
        ];
    }

    public function submit(): void
    {
        // 1) Piège anti-robot : un bot remplit le champ caché → on ignore silencieusement.
        if ($this->website !== '') {
            return;
        }

        // 2) Limitation de débit : 5 demandes / heure / IP.
        $cle = 'demande:' . request()->ip();
        if (RateLimiter::tooManyAttempts($cle, 5)) {
            $this->addError('rate_limit', 'Trop de demandes envoyées. Merci de réessayer plus tard.');
            return;
        }

        $data = $this->validate();
        RateLimiter::hit($cle, 3600);

        // 3) Enregistrement — AUCUN prix, aucun calcul, aucun appel API à ce stade.
        $demande = Demande::create([
            'reference'        => $this->genererReference(),
            'categorie_id'     => $data['categorie_id'],
            'nb_passagers'     => $data['nb_passagers'],
            'client_nom'       => $data['client_nom'],
            'client_email'     => $data['client_email'],
            'client_telephone' => $data['client_telephone'] ?: null,
            'statut'           => 'nouvelle',
            'commentaire'      => $data['commentaire'] ?: null,
            'ip_soumission'    => request()->ip(),
        ]);

        // On boucle sur l'état du composant : validate() n'ayant pas de règle
        // sur les cases à cocher, celles-ci sont absentes de $data.
        foreach (array_values($this->etapes) as $i => $e) {
            $demande->etapes()->create([
                'ordre'              => $i + 1,
                'commune_id'         => $e['commune_id'],
                'date'               => $e['date'],
                'heure_arrivee'      => $e['heure_arrivee'] ?: null,
                'heure_depart'       => $e['heure_depart'] ?: null,
                'arrivee_imperative' => (bool) ($e['arrivee_imperative'] ?? false),
                'depart_imperatif'   => (bool) ($e['depart_imperatif'] ?? false),
            ]);
        }

        $this->reference  = $demande->reference;
        $this->submitted  = true;
    }

    protected function genererReference(): string
    {
        return 'DEM-' . now()->format('Ymd') . '-' . Str::upper(Str::random(4));
    }

    public function render()
    {
        return view('livewire.demande-form');
    }
}
