<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Commune extends Model
{
    use HasFactory;

    protected $table = 'communes';

    /** Table de référence importée : pas d'horodatage. */
    public $timestamps = false;

    protected $fillable = [
        'code_insee',
        'nom',
        'code_postal',
        'latitude',
        'longitude',
    ];

    protected function casts(): array
    {
        return [
            'latitude'  => 'decimal:7',
            'longitude' => 'decimal:7',
        ];
    }

    public function etapes(): HasMany
    {
        return $this->hasMany(Etape::class);
    }
}
