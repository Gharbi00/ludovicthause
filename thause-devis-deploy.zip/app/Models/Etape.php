<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Etape extends Model
{
    use HasFactory;

    protected $table = 'etapes';

    protected $fillable = [
        'demande_id',
        'ordre',
        'commune_id',
        'date',
        'heure_arrivee',
        'heure_depart',
        'arrivee_imperative',
        'depart_imperatif',
        'temps_attente_minutes',
    ];

    protected function casts(): array
    {
        return [
            'ordre'                 => 'integer',
            'date'                  => 'date',
            'arrivee_imperative'    => 'boolean',
            'depart_imperatif'      => 'boolean',
            'temps_attente_minutes' => 'integer',
        ];
    }

    public function demande(): BelongsTo
    {
        return $this->belongsTo(Demande::class);
    }

    public function commune(): BelongsTo
    {
        return $this->belongsTo(Commune::class);
    }
}
