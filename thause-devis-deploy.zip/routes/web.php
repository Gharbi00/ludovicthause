<?php

use App\Livewire\DemandeForm;
use Illuminate\Support\Facades\Route;

// Front public : formulaire de demande de devis (Phase 2)
Route::get('/', DemandeForm::class)->name('demande.create');
