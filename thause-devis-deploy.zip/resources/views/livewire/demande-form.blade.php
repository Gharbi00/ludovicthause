<div>
    @if ($submitted)
        {{-- ---------- Accusé de réception ---------- --}}
        <div class="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 p-8 text-center">
            <div class="mx-auto h-14 w-14 rounded-full bg-green-100 flex items-center justify-center text-3xl">✅</div>
            <h1 class="mt-4 text-2xl font-semibold text-slate-900">Demande envoyée&nbsp;!</h1>
            <p class="mt-2 text-slate-600">
                Merci, votre demande de devis a bien été enregistrée sous la référence
                <span class="font-mono font-semibold text-brand">{{ $reference }}</span>.
            </p>
            <p class="mt-1 text-slate-600">
                Notre équipe étudie votre trajet et vous recontacte rapidement avec une proposition chiffrée.
            </p>
            <button wire:click="$refresh" onclick="window.location.reload()"
                    class="mt-6 inline-flex items-center rounded-lg bg-brand px-5 py-2.5 text-white font-medium hover:bg-brand-dark">
                Faire une nouvelle demande
            </button>
        </div>
    @else
        <form wire:submit="submit" class="space-y-6">
            @error('rate_limit')
                <div class="rounded-lg bg-red-50 p-4 text-sm text-red-700 ring-1 ring-red-200">{{ $message }}</div>
            @enderror

            {{-- ---------- 1. Le voyage ---------- --}}
            <section class="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 p-6">
                <h2 class="text-lg font-semibold text-slate-900 flex items-center gap-2">
                    <span class="text-brand">1.</span> Votre voyage
                </h2>
                <div class="mt-4 grid gap-5 sm:grid-cols-2">
                    <div>
                        <label class="block text-sm font-medium text-slate-700">Nombre de passagers</label>
                        <input type="number" min="1" max="120" wire:model.live="nb_passagers"
                               class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                        @error('nb_passagers') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700">Catégorie de véhicule</label>
                        <select wire:model="categorie_id"
                                class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                            <option value="">— Choisir —</option>
                            @foreach ($this->categories as $cat)
                                <option value="{{ $cat->id }}">{{ $cat->libelle }}</option>
                            @endforeach
                        </select>
                        @error('categorie_id') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                        @if ($this->categories->isEmpty())
                            <p class="mt-1 text-xs text-amber-600">Aucune catégorie ne couvre ce nombre de passagers.</p>
                        @endif
                    </div>
                </div>
            </section>

            {{-- ---------- 2. Itinéraire ---------- --}}
            <section class="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 p-6">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold text-slate-900 flex items-center gap-2">
                        <span class="text-brand">2.</span> Itinéraire &amp; étapes
                    </h2>
                    <span class="text-xs text-slate-400">{{ count($etapes) }} étape(s)</span>
                </div>

                <div class="mt-4 space-y-4">
                    @foreach ($etapes as $i => $etape)
                        <div class="rounded-xl border border-slate-200 p-4" wire:key="etape-{{ $i }}">
                            <div class="flex items-center justify-between mb-3">
                                <span class="inline-flex items-center gap-2 text-sm font-medium text-slate-700">
                                    <span class="h-6 w-6 rounded-full bg-brand text-white text-xs flex items-center justify-center">{{ $i + 1 }}</span>
                                    @if ($i === 0) Départ
                                    @elseif ($i === count($etapes) - 1) Arrivée / Retour
                                    @else Étape @endif
                                </span>
                                @if (count($etapes) > 2)
                                    <button type="button" wire:click="retirerEtape({{ $i }})"
                                            class="text-xs text-red-500 hover:text-red-700">Retirer</button>
                                @endif
                            </div>

                            <div class="grid gap-4 sm:grid-cols-2">
                                <div class="sm:col-span-2">
                                    <label class="block text-xs font-medium text-slate-600">Ville</label>
                                    <select wire:model="etapes.{{ $i }}.commune_id"
                                            class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                                        <option value="">— Choisir une ville —</option>
                                        @foreach ($this->communes as $commune)
                                            <option value="{{ $commune->id }}">{{ $commune->nom }} @if($commune->code_postal)({{ $commune->code_postal }})@endif</option>
                                        @endforeach
                                    </select>
                                    @error("etapes.$i.commune_id") <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600">Date</label>
                                    <input type="date" wire:model="etapes.{{ $i }}.date"
                                           class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                                    @error("etapes.$i.date") <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                                </div>
                                <div class="grid grid-cols-2 gap-2">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600">Arrivée</label>
                                        <input type="time" wire:model="etapes.{{ $i }}.heure_arrivee"
                                               class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600">Départ</label>
                                        <input type="time" wire:model="etapes.{{ $i }}.heure_depart"
                                               class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                                    </div>
                                </div>
                                <div class="sm:col-span-2 flex flex-wrap gap-x-6 gap-y-2 pt-1">
                                    <label class="inline-flex items-center gap-2 text-xs text-slate-600">
                                        <input type="checkbox" wire:model="etapes.{{ $i }}.arrivee_imperative"
                                               class="rounded border-slate-300 text-brand focus:ring-brand">
                                        Horaire d'arrivée impératif
                                    </label>
                                    <label class="inline-flex items-center gap-2 text-xs text-slate-600">
                                        <input type="checkbox" wire:model="etapes.{{ $i }}.depart_imperatif"
                                               class="rounded border-slate-300 text-brand focus:ring-brand">
                                        Horaire de départ impératif
                                    </label>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

                <button type="button" wire:click="ajouterEtape"
                        class="mt-4 inline-flex items-center gap-1 rounded-lg border border-dashed border-brand px-4 py-2 text-sm font-medium text-brand hover:bg-blue-50">
                    <span class="text-lg leading-none">+</span> Ajouter une étape
                </button>
            </section>

            {{-- ---------- 3. Coordonnées ---------- --}}
            <section class="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 p-6">
                <h2 class="text-lg font-semibold text-slate-900 flex items-center gap-2">
                    <span class="text-brand">3.</span> Vos coordonnées
                </h2>
                <div class="mt-4 grid gap-5 sm:grid-cols-2">
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-medium text-slate-700">Nom / Organisation</label>
                        <input type="text" wire:model="client_nom"
                               class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                        @error('client_nom') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700">E-mail</label>
                        <input type="email" wire:model="client_email"
                               class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                        @error('client_email') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700">Téléphone</label>
                        <input type="tel" wire:model="client_telephone"
                               class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand">
                    </div>
                    <div class="sm:col-span-2">
                        <label class="block text-sm font-medium text-slate-700">Précisions (facultatif)</label>
                        <textarea wire:model="commentaire" rows="3"
                                  class="mt-1 w-full rounded-lg border-slate-300 shadow-sm focus:border-brand focus:ring-brand"></textarea>
                    </div>
                </div>

                {{-- Champ piège anti-robot : masqué aux humains --}}
                <div class="hidden" aria-hidden="true">
                    <label>Ne pas remplir <input type="text" wire:model="website" tabindex="-1" autocomplete="off"></label>
                </div>
            </section>

            <div class="flex items-center justify-between gap-4">
                <p class="text-xs text-slate-400">Aucun tarif n'est affiché : notre équipe chiffre votre demande manuellement.</p>
                <button type="submit"
                        class="inline-flex items-center rounded-lg bg-brand px-6 py-3 text-white font-semibold shadow-sm hover:bg-brand-dark disabled:opacity-50"
                        wire:loading.attr="disabled">
                    <span wire:loading.remove wire:target="submit">Envoyer ma demande</span>
                    <span wire:loading wire:target="submit">Envoi…</span>
                </button>
            </div>
        </form>
    @endif
</div>
