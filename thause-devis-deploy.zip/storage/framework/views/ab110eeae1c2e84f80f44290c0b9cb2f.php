<!DOCTYPE html>
<html lang="fr" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'Ludovic Thause Tourisme — Demande de devis'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: { extend: { colors: { brand: { DEFAULT: '#1d4ed8', dark: '#1e3a8a' } } } }
        }
    </script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="h-full bg-slate-100 text-slate-800 antialiased">
    <header class="bg-brand-dark text-white">
        <div class="mx-auto max-w-3xl px-4 py-5 flex items-center gap-3">
            <div class="h-10 w-10 rounded-full bg-white/15 flex items-center justify-center text-xl">🚌</div>
            <div>
                <p class="text-lg font-semibold leading-tight">Ludovic Thause Tourisme</p>
                <p class="text-sm text-blue-200">Demande de devis — transport en autocar</p>
            </div>
        </div>
    </header>

    <main class="mx-auto max-w-3xl px-4 py-8">
        <?php echo e($slot); ?>

    </main>

    <footer class="mx-auto max-w-3xl px-4 py-6 text-center text-xs text-slate-400">
        LTT — Varennes-Vauzelles · Démonstration DoliExpert
    </footer>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH /Users/christopheducros/Desktop/EN_COURS/LUDOVIC-THAUSE/thause-devis/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>