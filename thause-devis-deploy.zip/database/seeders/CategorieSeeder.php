<?php

namespace Database\Seeders;

use App\Models\Categorie;
use Illuminate\Database\Seeder;

class CategorieSeeder extends Seeder
{
    /**
     * Catégories de démonstration (gabarits par capacité).
     * Le client choisit une catégorie ; la secrétaire affecte le véhicule réel.
     */
    public function run(): void
    {
        $categories = [
            ['libelle' => 'Minibus (jusqu\'à 19 places)',        'capacite' => 19, 'gabarit' => 'minibus'],
            ['libelle' => 'Midicar (jusqu\'à 35 places)',        'capacite' => 35, 'gabarit' => 'midicar'],
            ['libelle' => 'Autocar standard (jusqu\'à 49 places)', 'capacite' => 49, 'gabarit' => 'standard'],
            ['libelle' => 'Grand tourisme (jusqu\'à 59 places)',  'capacite' => 59, 'gabarit' => 'grand_tourisme'],
            ['libelle' => 'Grand tourisme (jusqu\'à 63 places)',  'capacite' => 63, 'gabarit' => 'grand_tourisme'],
        ];

        foreach ($categories as $c) {
            Categorie::updateOrCreate(['libelle' => $c['libelle']], $c + ['actif' => true]);
        }
    }
}
