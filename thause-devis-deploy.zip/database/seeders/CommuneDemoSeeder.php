<?php

namespace Database\Seeders;

use App\Models\Commune;
use Illuminate\Database\Seeder;

class CommuneDemoSeeder extends Seeder
{
    /**
     * Jeu de communes de DÉMONSTRATION pour tester l'autocomplétion.
     * Sera remplacé par l'import complet BAN/INSEE en Phase 1 (php artisan communes:import).
     */
    public function run(): void
    {
        $communes = [
            ['code_insee' => '58303', 'nom' => 'Varennes-Vauzelles', 'code_postal' => '58640', 'latitude' => 47.0289, 'longitude' => 3.1519], // dépôt LTT
            ['code_insee' => '58194', 'nom' => 'Nevers',             'code_postal' => '58000', 'latitude' => 46.9896, 'longitude' => 3.1590],
            ['code_insee' => '75056', 'nom' => 'Paris',              'code_postal' => '75001', 'latitude' => 48.8566, 'longitude' => 2.3522],
            ['code_insee' => '69123', 'nom' => 'Lyon',               'code_postal' => '69001', 'latitude' => 45.7640, 'longitude' => 4.8357],
            ['code_insee' => '13055', 'nom' => 'Marseille',          'code_postal' => '13001', 'latitude' => 43.2965, 'longitude' => 5.3698],
            ['code_insee' => '31555', 'nom' => 'Toulouse',           'code_postal' => '31000', 'latitude' => 43.6047, 'longitude' => 1.4442],
            ['code_insee' => '06088', 'nom' => 'Nice',               'code_postal' => '06000', 'latitude' => 43.7102, 'longitude' => 7.2620],
            ['code_insee' => '44109', 'nom' => 'Nantes',             'code_postal' => '44000', 'latitude' => 47.2184, 'longitude' => -1.5536],
            ['code_insee' => '34172', 'nom' => 'Montpellier',        'code_postal' => '34000', 'latitude' => 43.6108, 'longitude' => 3.8767],
            ['code_insee' => '67482', 'nom' => 'Strasbourg',         'code_postal' => '67000', 'latitude' => 48.5734, 'longitude' => 7.7521],
            ['code_insee' => '33063', 'nom' => 'Bordeaux',           'code_postal' => '33000', 'latitude' => 44.8378, 'longitude' => -0.5792],
            ['code_insee' => '59350', 'nom' => 'Lille',              'code_postal' => '59000', 'latitude' => 50.6292, 'longitude' => 3.0573],
            ['code_insee' => '35238', 'nom' => 'Rennes',             'code_postal' => '35000', 'latitude' => 48.1173, 'longitude' => -1.6778],
            ['code_insee' => '51454', 'nom' => 'Reims',              'code_postal' => '51100', 'latitude' => 49.2583, 'longitude' => 4.0317],
            ['code_insee' => '21231', 'nom' => 'Dijon',              'code_postal' => '21000', 'latitude' => 47.3220, 'longitude' => 5.0415],
            ['code_insee' => '38185', 'nom' => 'Grenoble',           'code_postal' => '38000', 'latitude' => 45.1885, 'longitude' => 5.7245],
            ['code_insee' => '76540', 'nom' => 'Rouen',              'code_postal' => '76000', 'latitude' => 49.4432, 'longitude' => 1.0999],
            ['code_insee' => '63113', 'nom' => 'Clermont-Ferrand',   'code_postal' => '63000', 'latitude' => 45.7772, 'longitude' => 3.0870],
            ['code_insee' => '18033', 'nom' => 'Bourges',            'code_postal' => '18000', 'latitude' => 47.0810, 'longitude' => 2.3988],
            ['code_insee' => '45234', 'nom' => 'Orléans',            'code_postal' => '45000', 'latitude' => 47.9029, 'longitude' => 1.9093],
            ['code_insee' => '71076', 'nom' => 'Chalon-sur-Saône',   'code_postal' => '71100', 'latitude' => 46.7806, 'longitude' => 4.8531],
            ['code_insee' => '03185', 'nom' => 'Moulins',            'code_postal' => '03000', 'latitude' => 46.5667, 'longitude' => 3.3333],
            ['code_insee' => '89024', 'nom' => 'Auxerre',            'code_postal' => '89000', 'latitude' => 47.7982, 'longitude' => 3.5735],
            ['code_insee' => '37261', 'nom' => 'Tours',              'code_postal' => '37000', 'latitude' => 47.3941, 'longitude' => 0.6848],
            // Europe (voyages transfrontaliers)
            ['code_insee' => null,    'nom' => 'Genève (Suisse)',    'code_postal' => '1200',  'latitude' => 46.2044, 'longitude' => 6.1432],
            ['code_insee' => null,    'nom' => 'Barcelone (Espagne)', 'code_postal' => '08001', 'latitude' => 41.3851, 'longitude' => 2.1734],
            ['code_insee' => null,    'nom' => 'Milan (Italie)',     'code_postal' => '20100', 'latitude' => 45.4642, 'longitude' => 9.1900],
            ['code_insee' => null,    'nom' => 'Bruxelles (Belgique)', 'code_postal' => '1000', 'latitude' => 50.8503, 'longitude' => 4.3517],
            ['code_insee' => null,    'nom' => 'Francfort (Allemagne)', 'code_postal' => '60311', 'latitude' => 50.1109, 'longitude' => 8.6821],
        ];

        foreach ($communes as $c) {
            Commune::updateOrCreate(
                ['nom' => $c['nom'], 'code_postal' => $c['code_postal']],
                $c
            );
        }
    }
}
