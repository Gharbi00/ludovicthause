<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call(ParametreSeeder::class);
        $this->call(CategorieSeeder::class);
        $this->call(CommuneDemoSeeder::class);

        // Compte secrétaire de démonstration
        User::factory()->create([
            'name'  => 'Secrétaire LTT',
            'email' => 'secretaire@ludovicthause.fr',
            'role'  => 'secretaire',
        ]);
    }
}
