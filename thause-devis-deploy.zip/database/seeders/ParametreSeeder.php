<?php

namespace Database\Seeders;

use App\Models\Parametre;
use Illuminate\Database\Seeder;

class ParametreSeeder extends Seeder
{
    /**
     * Paramètres par défaut. Les valeurs marquées « à renseigner » (0 / vide)
     * doivent être complétées en Phase 6 avec les vraies données LTT.
     */
    public function run(): void
    {
        $parametres = [
            // --- Calcul / fiscalité ---
            ['cle' => 'taux_tva',              'valeur' => '10',   'type' => 'decimal', 'groupe' => 'calcul',    'libelle' => 'Taux de TVA transport voyageurs (%)'],
            ['cle' => 'marge_cible',           'valeur' => '15',   'type' => 'decimal', 'groupe' => 'calcul',    'libelle' => 'Marge cible par défaut (%)'],
            ['cle' => 'coef_saisonnalite',     'valeur' => '1.0',  'type' => 'decimal', 'groupe' => 'calcul',    'libelle' => 'Coefficient de saisonnalité (réallocation charges fixes)'],

            // --- Structure / chauffeur ---
            ['cle' => 'taux_horaire_chauffeur', 'valeur' => '0',   'type' => 'decimal', 'groupe' => 'structure', 'libelle' => 'Taux horaire chauffeur (€/h) — À RENSEIGNER'],
            ['cle' => 'depot_commune_id',       'valeur' => null,  'type' => 'integer', 'groupe' => 'structure', 'libelle' => 'Commune du dépôt (Varennes-Vauzelles) — à lier après import communes'],

            // --- Carburant ---
            ['cle' => 'prix_gasoil_litre',     'valeur' => '1.70', 'type' => 'decimal', 'groupe' => 'carburant', 'libelle' => 'Prix du gasoil (€/L) — indexable via prix-carburants.gouv.fr'],

            // --- RSE (règlement 561/2006, seuils à figer au dev du bloc) ---
            ['cle' => 'rse_conduite_journaliere_max_min', 'valeur' => '540', 'type' => 'integer', 'groupe' => 'rse', 'libelle' => 'Conduite journalière max (min) — 9h'],
            ['cle' => 'rse_conduite_avant_pause_min',     'valeur' => '270', 'type' => 'integer', 'groupe' => 'rse', 'libelle' => 'Conduite avant pause obligatoire (min) — 4h30'],
            ['cle' => 'rse_duree_pause_min',              'valeur' => '45',  'type' => 'integer', 'groupe' => 'rse', 'libelle' => 'Durée pause (min) — fractionnable 15+30'],
            ['cle' => 'rse_repos_journalier_min',         'valeur' => '660', 'type' => 'integer', 'groupe' => 'rse', 'libelle' => 'Repos journalier (min) — 11h'],

            // --- Clés API (à renseigner en réglages) ---
            ['cle' => 'here_api_key',      'valeur' => '', 'type' => 'string', 'groupe' => 'api', 'libelle' => 'Clé API HERE (routage + péage)'],
            ['cle' => 'tollguru_api_key',  'valeur' => '', 'type' => 'string', 'groupe' => 'api', 'libelle' => 'Clé API TollGuru (repli péage)'],
            ['cle' => 'peage_provider',    'valeur' => 'here', 'type' => 'string', 'groupe' => 'api', 'libelle' => 'Fournisseur de péage actif : here | tollguru'],
        ];

        foreach ($parametres as $p) {
            Parametre::updateOrCreate(['cle' => $p['cle']], $p);
        }
    }
}
